RainFall Background (c) by PremedLynx

RainFall Background is licensed under a
Creative Commons Attribution 4.0 International License.

- License -
This art piece is licensed under a Creative Commons Atribution 4.0 International license CC BY 4.0,
which reads the following:

You are free to:
  Share — copy and redistribute the material in any medium or format for any purpose, even commercially.
  Adapt — remix, transform, and build upon the material for any purpose, even commercially.
The licensor cannot revoke these freedoms as long as you follow the license terms.

Under the following terms:
  Attribution — You must give appropriate credit , provide a link to the license, and indicate if changes were made . You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
  No additional restrictions — You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.

You should have received a copy of the license along with this
work. If not, see <https://creativecommons.org/licenses/by/4.0/>